package com.dineflow.service;

import com.dineflow.dto.TableRequest;
import com.dineflow.dto.TableResponse;
import com.dineflow.entity.RestaurantTable;
import com.dineflow.entity.TableStatus;
import com.dineflow.repository.OrderRepository;
import com.dineflow.repository.TableRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TableService {

    private final TableRepository tableRepository;
    private final OrderRepository orderRepository;

    @Value("${app.frontend.url:http://localhost:5173}")
    private String frontendUrl;

    @Transactional(readOnly = true)
    public List<TableResponse> getAllTables(boolean activeOnly) {
        List<RestaurantTable> tables = activeOnly
                ? tableRepository.findByActiveTrueOrderByTableNumberAsc()
                : tableRepository.findAllByOrderByTableNumberAsc();

        return tables.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public TableResponse getTableById(Long id) {
        RestaurantTable table = tableRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Table not found with id: " + id));
        return mapToResponse(table);
    }

    @Transactional(readOnly = true)
    public TableResponse resolveTable(String tokenOrNumber) {
        // First try by QR code token
        RestaurantTable table = tableRepository.findByQrCodeToken(tokenOrNumber)
                .orElseGet(() -> tableRepository.findByTableNumberIgnoreCase(tokenOrNumber)
                        .orElseThrow(() -> new RuntimeException("Table not found: " + tokenOrNumber)));

        if (!table.isActive()) {
            throw new RuntimeException("This table is currently inactive.");
        }

        return mapToResponse(table);
    }

    @Transactional
    public TableResponse createTable(TableRequest request) {
        String cleanNumber = request.getTableNumber().trim().toUpperCase();
        if (tableRepository.existsByTableNumberIgnoreCase(cleanNumber)) {
            throw new RuntimeException("Table with number '" + cleanNumber + "' already exists");
        }

        RestaurantTable table = RestaurantTable.builder()
                .tableNumber(cleanNumber)
                .capacity(request.getCapacity() != null ? request.getCapacity() : 4)
                .qrCodeToken(UUID.randomUUID().toString())
                .status(request.getStatus() != null ? request.getStatus() : TableStatus.AVAILABLE)
                .active(request.getActive() != null ? request.getActive() : true)
                .build();

        return mapToResponse(tableRepository.save(table));
    }

    @Transactional
    public TableResponse updateTable(Long id, TableRequest request) {
        RestaurantTable table = tableRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Table not found with id: " + id));

        String cleanNumber = request.getTableNumber().trim().toUpperCase();
        if (!table.getTableNumber().equalsIgnoreCase(cleanNumber) &&
                tableRepository.existsByTableNumberIgnoreCase(cleanNumber)) {
            throw new RuntimeException("Another table with number '" + cleanNumber + "' already exists");
        }

        table.setTableNumber(cleanNumber);
        if (request.getCapacity() != null) {
            table.setCapacity(request.getCapacity());
        }
        if (request.getStatus() != null) {
            table.setStatus(request.getStatus());
        }
        if (request.getActive() != null) {
            table.setActive(request.getActive());
        }

        return mapToResponse(tableRepository.save(table));
    }

    @Transactional
    public void deleteTable(Long id) {
        RestaurantTable table = tableRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Table not found with id: " + id));

        int activeOrders = orderRepository.findActiveOrdersByTable(table.getTableNumber()).size();
        if (activeOrders > 0) {
            throw new RuntimeException("Cannot delete table with " + activeOrders + " active orders. Please complete or cancel orders first.");
        }

        tableRepository.delete(table);
    }

    @Transactional
    public TableResponse regenerateQrToken(Long id) {
        RestaurantTable table = tableRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Table not found with id: " + id));

        table.setQrCodeToken(UUID.randomUUID().toString());
        return mapToResponse(tableRepository.save(table));
    }

    private TableResponse mapToResponse(RestaurantTable t) {
        int activeOrders = orderRepository.findActiveOrdersByTable(t.getTableNumber()).size();
        String qrUrl = frontendUrl + "/table/" + t.getTableNumber();

        return TableResponse.builder()
                .id(t.getId())
                .tableNumber(t.getTableNumber())
                .capacity(t.getCapacity())
                .qrCodeToken(t.getQrCodeToken())
                .qrUrl(qrUrl)
                .status(t.getStatus())
                .active(t.isActive())
                .activeOrderCount(activeOrders)
                .createdAt(t.getCreatedAt())
                .build();
    }
}

