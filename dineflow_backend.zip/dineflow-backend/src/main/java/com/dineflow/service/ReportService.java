package com.dineflow.service;

import com.dineflow.dto.ReportResponse;
import com.dineflow.entity.OrderStatus;
import com.dineflow.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final OrderRepository orderRepository;

    @Transactional(readOnly = true)
    public ReportResponse getSummaryReport() {
        BigDecimal revenue = orderRepository.sumTotalRevenue();
        if (revenue == null) revenue = BigDecimal.ZERO;

        long totalOrders = orderRepository.count();
        long completed   = orderRepository.countCompleted();
        long pending     = orderRepository.countByStatus(OrderStatus.PENDING)
                         + orderRepository.countByStatus(OrderStatus.CONFIRMED)
                         + orderRepository.countByStatus(OrderStatus.PREPARING)
                         + orderRepository.countByStatus(OrderStatus.READY);

        BigDecimal avg = orderRepository.avgOrderValue();
        if (avg == null) avg = BigDecimal.ZERO;

        // Top dishes
        List<Object[]> topRaw = orderRepository.findTopDishes();
        List<ReportResponse.TopDish> topDishes = topRaw.stream()
                .limit(10)
                .map(row -> ReportResponse.TopDish.builder()
                        .dishName((String) row[0])
                        .totalQuantity(((Number) row[1]).longValue())
                        .totalRevenue(new BigDecimal(row[2].toString()))
                        .build())
                .collect(Collectors.toList());

        // Daily revenue (last 30 days)
        List<Object[]> dailyRaw = orderRepository.findDailyRevenue();
        List<ReportResponse.DailyRevenue> daily = dailyRaw.stream()
                .map(row -> ReportResponse.DailyRevenue.builder()
                        .date(row[0].toString())
                        .revenue(new BigDecimal(row[1].toString()))
                        .orders(((Number) row[2]).longValue())
                        .build())
                .collect(Collectors.toList());

        return ReportResponse.builder()
                .totalRevenue(revenue)
                .totalOrders(totalOrders)
                .completedOrders(completed)
                .pendingOrders(pending)
                .avgOrderValue(avg.setScale(2, java.math.RoundingMode.HALF_UP))
                .topDishes(topDishes)
                .dailyRevenue(daily)
                .build();
    }
}

