package com.dineflow.service;

import com.dineflow.dto.*;
import com.dineflow.entity.*;
import com.dineflow.repository.DishRepository;
import com.dineflow.repository.OrderItemRepository;
import com.dineflow.repository.OrderRepository;
import com.dineflow.repository.TableRepository;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final TableRepository tableRepository;
    private final DishRepository dishRepository;

    @Transactional
    public OrderResponse placeOrder(OrderRequest request) {
        // Resolve Table by number or QR token
        String identifier = request.getTableNumber().trim();
        RestaurantTable table = tableRepository.findByTableNumberIgnoreCase(identifier)
                .orElseGet(() -> tableRepository.findByQrCodeToken(identifier)
                        .orElseThrow(() -> new RuntimeException("Table not found: " + identifier)));

        if (!table.isActive()) {
            throw new RuntimeException("This table is currently inactive.");
        }

        // Generate clean Order Number (e.g. ORD-20261113-7482)
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String randomSuffix = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        String orderNumber = "ORD-" + timestamp + "-" + randomSuffix;

        Order order = Order.builder()
                .orderNumber(orderNumber)
                .table(table)
                .customerName(request.getCustomerName().trim())
                .customerSessionId(request.getCustomerSessionId().trim())
                .specialInstructions(request.getSpecialInstructions())
                .status(OrderStatus.PENDING)
                .paymentStatus(PaymentStatus.UNPAID)
                .totalAmount(BigDecimal.ZERO)
                .build();

        BigDecimal runningTotal = BigDecimal.ZERO;

        for (OrderItemRequest itemReq : request.getItems()) {
            Dish dish = dishRepository.findById(itemReq.getDishId())
                    .orElseThrow(() -> new RuntimeException("Dish not found with id: " + itemReq.getDishId()));

            if (!dish.isAvailable()) {
                throw new RuntimeException("Sorry, '" + dish.getName() + "' is currently out of stock!");
            }

            BigDecimal itemPrice = dish.getPrice();
            BigDecimal subtotal = itemPrice.multiply(BigDecimal.valueOf(itemReq.getQuantity()));
            runningTotal = runningTotal.add(subtotal);

            OrderItem orderItem = OrderItem.builder()
                    .dish(dish)
                    .dishName(dish.getName())
                    .price(itemPrice)
                    .quantity(itemReq.getQuantity())
                    .subtotal(subtotal)
                    .itemStatus(ItemStatus.QUEUED)
                    .specialNotes(itemReq.getSpecialNotes())
                    .build();

            order.addItem(orderItem);
        }

        order.setTotalAmount(runningTotal);

        // Update table to OCCUPIED when an active order is placed
        if (table.getStatus() == TableStatus.AVAILABLE) {
            table.setStatus(TableStatus.OCCUPIED);
            tableRepository.save(table);
        }

        Order saved = orderRepository.save(order);
        log.info("New order placed: {} by {} for table {} (Total: ₹{})", 
                saved.getOrderNumber(), saved.getCustomerName(), table.getTableNumber(), saved.getTotalAmount());

        return mapToResponse(saved);
    }

    @Transactional(readOnly = true)
    public OrderResponse getOrderByNumber(String orderNumber) {
        Order order = orderRepository.findByOrderNumber(orderNumber.trim())
                .orElseThrow(() -> new RuntimeException("Order not found with number: " + orderNumber));
        return mapToResponse(order);
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getOrdersByCustomerSession(String sessionId) {
        return orderRepository.findByCustomerSessionIdOrderByCreatedAtDesc(sessionId)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getActiveOrdersByTable(String tableNumber) {
        return orderRepository.findActiveOrdersByTable(tableNumber.trim())
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> getAllOrders(OrderStatus status) {
        List<Order> list = (status != null)
                ? orderRepository.findByStatusInOrderByCreatedAtDesc(List.of(status))
                : orderRepository.findAllByOrderByCreatedAtDesc();

        return list.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, OrderStatusUpdateRequest request) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));

        if (request.getStatus() != null) {
            order.setStatus(request.getStatus());

            // If order status moves to PREPARING, also advance queued items
            if (request.getStatus() == OrderStatus.PREPARING) {
                order.getItems().forEach(i -> {
                    if (i.getItemStatus() == ItemStatus.QUEUED) {
                        i.setItemStatus(ItemStatus.COOKING);
                    }
                });
            } else if (request.getStatus() == OrderStatus.READY) {
                order.getItems().forEach(i -> i.setItemStatus(ItemStatus.READY));
            } else if (request.getStatus() == OrderStatus.SERVED || request.getStatus() == OrderStatus.COMPLETED) {
                order.getItems().forEach(i -> i.setItemStatus(ItemStatus.SERVED));
            }
        }

        if (request.getPaymentStatus() != null) {
            order.setPaymentStatus(request.getPaymentStatus());
        }

        // If specific item status was updated
        if (request.getItemId() != null && request.getItemStatus() != null) {
            order.getItems().stream()
                    .filter(i -> i.getId().equals(request.getItemId()))
                    .findFirst()
                    .ifPresent(i -> i.setItemStatus(request.getItemStatus()));
        }

        return mapToResponse(orderRepository.save(order));
    }

    // ─── Kitchen Methods ───────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<OrderResponse> getKitchenOrders() {
        List<OrderStatus> activeStatuses = List.of(
                OrderStatus.PENDING, OrderStatus.CONFIRMED,
                OrderStatus.PREPARING, OrderStatus.READY
        );
        return orderRepository.findByStatusInOrderByCreatedAtAsc(activeStatuses)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public OrderResponse updateItemStatus(Long itemId, ItemStatus newStatus) {
        OrderItem item = orderItemRepository.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Order item not found: " + itemId));
        item.setItemStatus(newStatus);
        orderItemRepository.save(item);
        // reload full order to return
        return mapToResponse(item.getOrder());
    }

    @Transactional(readOnly = true)
    public KitchenStatsResponse getKitchenStats() {
        long pending   = orderRepository.countByStatus(OrderStatus.PENDING);
        long confirmed = orderRepository.countByStatus(OrderStatus.CONFIRMED);
        long preparing = orderRepository.countByStatus(OrderStatus.PREPARING);
        long ready     = orderRepository.countByStatus(OrderStatus.READY);
        return KitchenStatsResponse.builder()
                .totalActive(pending + confirmed + preparing + ready)
                .pending(pending)
                .confirmed(confirmed)
                .preparing(preparing)
                .ready(ready)
                .build();
    }

    public OrderResponse mapToResponse(Order o) {
        List<OrderItemResponse> itemResponses = o.getItems().stream().map(i -> OrderItemResponse.builder()
                .id(i.getId())
                .dishId(i.getDish() != null ? i.getDish().getId() : null)
                .dishName(i.getDishName())
                .imageUrl(i.getDish() != null ? i.getDish().getImageUrl() : null)
                .dietaryType(i.getDish() != null ? i.getDish().getDietaryType() : DietaryType.VEG)
                .price(i.getPrice())
                .quantity(i.getQuantity())
                .subtotal(i.getSubtotal())
                .itemStatus(i.getItemStatus())
                .specialNotes(i.getSpecialNotes())
                .build()
        ).collect(Collectors.toList());

        return OrderResponse.builder()
                .id(o.getId())
                .orderNumber(o.getOrderNumber())
                .tableId(o.getTable() != null ? o.getTable().getId() : null)
                .tableNumber(o.getTable() != null ? o.getTable().getTableNumber() : "Unknown")
                .customerName(o.getCustomerName())
                .customerSessionId(o.getCustomerSessionId())
                .status(o.getStatus())
                .paymentStatus(o.getPaymentStatus())
                .totalAmount(o.getTotalAmount())
                .specialInstructions(o.getSpecialInstructions())
                .items(itemResponses)
                .createdAt(o.getCreatedAt())
                .updatedAt(o.getUpdatedAt())
                .build();
    }
}

