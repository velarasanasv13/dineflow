package com.dineflow.service;

import com.dineflow.dto.DishRequest;
import com.dineflow.dto.DishResponse;
import com.dineflow.dto.MenuStatsResponse;
import com.dineflow.entity.Category;
import com.dineflow.entity.DietaryType;
import com.dineflow.entity.Dish;
import com.dineflow.repository.CategoryRepository;
import com.dineflow.repository.DishRepository;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DishService {

    private final DishRepository dishRepository;
    private final CategoryRepository categoryRepository;

    @Transactional(readOnly = true)
    public List<DishResponse> searchDishes(Long categoryId, DietaryType dietaryType, Boolean available, String search) {
        Specification<Dish> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (categoryId != null) {
                predicates.add(cb.equal(root.get("category").get("id"), categoryId));
            }

            if (dietaryType != null) {
                predicates.add(cb.equal(root.get("dietaryType"), dietaryType));
            }

            if (available != null) {
                predicates.add(cb.equal(root.get("available"), available));
            }

            if (search != null && !search.trim().isEmpty()) {
                String pattern = "%" + search.trim().toLowerCase() + "%";
                Predicate nameMatch = cb.like(cb.lower(root.get("name")), pattern);
                Predicate descMatch = cb.like(cb.lower(root.get("description")), pattern);
                predicates.add(cb.or(nameMatch, descMatch));
            }

            query.orderBy(cb.desc(root.get("id")));
            return cb.and(predicates.toArray(new Predicate[0]));
        };

        return dishRepository.findAll(spec)
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public DishResponse getDishById(Long id) {
        Dish dish = dishRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Dish not found with id: " + id));
        return mapToResponse(dish);
    }

    @Transactional
    public DishResponse createDish(DishRequest request) {
        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found with id: " + request.getCategoryId()));

        Dish dish = Dish.builder()
                .name(request.getName().trim())
                .description(request.getDescription())
                .price(request.getPrice())
                .imageUrl(request.getImageUrl())
                .available(request.getAvailable() != null ? request.getAvailable() : true)
                .dietaryType(request.getDietaryType() != null ? request.getDietaryType() : DietaryType.VEG)
                .category(category)
                .prepTimeMinutes(request.getPrepTimeMinutes() != null ? request.getPrepTimeMinutes() : 15)
                .spicyLevel(request.getSpicyLevel() != null ? request.getSpicyLevel() : 1)
                .featured(request.getFeatured() != null ? request.getFeatured() : false)
                .build();

        return mapToResponse(dishRepository.save(dish));
    }

    @Transactional
    public DishResponse updateDish(Long id, DishRequest request) {
        Dish dish = dishRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Dish not found with id: " + id));

        Category category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found with id: " + request.getCategoryId()));

        dish.setName(request.getName().trim());
        dish.setDescription(request.getDescription());
        dish.setPrice(request.getPrice());
        dish.setImageUrl(request.getImageUrl());
        if (request.getAvailable() != null) {
            dish.setAvailable(request.getAvailable());
        }
        if (request.getDietaryType() != null) {
            dish.setDietaryType(request.getDietaryType());
        }
        dish.setCategory(category);
        if (request.getPrepTimeMinutes() != null) {
            dish.setPrepTimeMinutes(request.getPrepTimeMinutes());
        }
        if (request.getSpicyLevel() != null) {
            dish.setSpicyLevel(request.getSpicyLevel());
        }
        if (request.getFeatured() != null) {
            dish.setFeatured(request.getFeatured());
        }

        return mapToResponse(dishRepository.save(dish));
    }

    @Transactional
    public DishResponse toggleAvailability(Long id, Boolean available) {
        Dish dish = dishRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Dish not found with id: " + id));

        if (available != null) {
            dish.setAvailable(available);
        } else {
            dish.setAvailable(!dish.isAvailable());
        }

        return mapToResponse(dishRepository.save(dish));
    }

    @Transactional
    public void deleteDish(Long id) {
        if (!dishRepository.existsById(id)) {
            throw new RuntimeException("Dish not found with id: " + id);
        }
        dishRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public MenuStatsResponse getMenuStats() {
        long totalDishes = dishRepository.count();
        long inStock = dishRepository.countByAvailable(true);
        long outOfStock = dishRepository.countByAvailable(false);
        long totalCategories = categoryRepository.count();
        long vegDishes = dishRepository.findByDietaryType(DietaryType.VEG).size();
        long nonVegDishes = dishRepository.findByDietaryType(DietaryType.NON_VEG).size();

        return MenuStatsResponse.builder()
                .totalDishes(totalDishes)
                .inStockDishes(inStock)
                .outOfStockDishes(outOfStock)
                .totalCategories(totalCategories)
                .vegDishes(vegDishes)
                .nonVegDishes(nonVegDishes)
                .build();
    }

    private DishResponse mapToResponse(Dish d) {
        return DishResponse.builder()
                .id(d.getId())
                .name(d.getName())
                .description(d.getDescription())
                .price(d.getPrice())
                .imageUrl(d.getImageUrl())
                .available(d.isAvailable())
                .dietaryType(d.getDietaryType())
                .categoryId(d.getCategory() != null ? d.getCategory().getId() : null)
                .categoryName(d.getCategory() != null ? d.getCategory().getName() : null)
                .prepTimeMinutes(d.getPrepTimeMinutes())
                .spicyLevel(d.getSpicyLevel())
                .featured(d.isFeatured())
                .createdAt(d.getCreatedAt())
                .updatedAt(d.getUpdatedAt())
                .build();
    }
}
