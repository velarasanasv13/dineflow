package com.dineflow.service;

import com.dineflow.dto.BillResponse;
import com.dineflow.entity.Order;
import com.dineflow.entity.PaymentStatus;
import com.dineflow.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BillingService {

    private static final BigDecimal GST_RATE = new BigDecimal("0.05"); // 5% GST

    private final OrderRepository orderRepository;

    @Transactional(readOnly = true)
    public BillResponse generateBill(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        return buildBill(order);
    }

    @Transactional(readOnly = true)
    public BillResponse generateBillByNumber(String orderNumber) {
        Order order = orderRepository.findByOrderNumber(orderNumber.trim())
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderNumber));
        return buildBill(order);
    }

    @Transactional
    public BillResponse markPaid(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        order.setPaymentStatus(PaymentStatus.PAID);
        orderRepository.save(order);
        return buildBill(order);
    }

    private BillResponse buildBill(Order order) {
        List<BillResponse.BillItemLine> lines = order.getItems().stream()
                .map(i -> BillResponse.BillItemLine.builder()
                        .dishName(i.getDishName())
                        .quantity(i.getQuantity())
                        .price(i.getPrice())
                        .subtotal(i.getSubtotal())
                        .build())
                .collect(Collectors.toList());

        BigDecimal subtotal = order.getTotalAmount();
        BigDecimal gstAmt   = subtotal.multiply(GST_RATE).setScale(2, RoundingMode.HALF_UP);
        BigDecimal grandTotal = subtotal.add(gstAmt).setScale(2, RoundingMode.HALF_UP);

        return BillResponse.builder()
                .orderId(order.getId())
                .orderNumber(order.getOrderNumber())
                .tableNumber(order.getTable() != null ? order.getTable().getTableNumber() : "N/A")
                .customerName(order.getCustomerName())
                .items(lines)
                .subtotal(subtotal)
                .gstRate(GST_RATE)
                .gstAmount(gstAmt)
                .grandTotal(grandTotal)
                .paymentStatus(order.getPaymentStatus().name())
                .status(order.getStatus().name())
                .build();
    }
}

